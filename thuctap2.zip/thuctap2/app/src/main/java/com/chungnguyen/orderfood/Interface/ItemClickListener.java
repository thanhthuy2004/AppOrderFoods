package com.chungnguyen.orderfood.Interface;

import android.view.View;



public interface ItemClickListener {
    void onClick(View view , int posittion, boolean isLongClick);
}
